/* C Square Program written by Andrew Ricci*/

#include <stdio.h>

long square(long x){
    long y = x * x;
    return y;
}
