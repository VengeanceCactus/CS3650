
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "vec.h"

vec*
read_matrix(long* nn)
{
    *nn = 2;
    return make_vec();
}

void
transpose(vec* mat, long nn)
{
    // TODO: transpose
}

void
print_matrix(vec* mat, long nn)
{
    char five[] = "5\n";
    write(1, five, 2);
}

int
main(int _ac, char* _av[])
{
    long nn;
    vec* vv = read_matrix(&nn);
    transpose(vv, nn);
    print_matrix(vv, nn);
    return 0;
}

